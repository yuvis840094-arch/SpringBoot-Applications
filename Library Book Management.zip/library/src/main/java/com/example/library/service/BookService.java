package com.example.library.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.library.model.Book;
import com.example.library.repository.BookRepository;

@Service
public class BookService {

    private final BookRepository repository;

    public BookService(BookRepository repository) {
        this.repository = repository;
    }

    public List<Book> getAllBooks() {
        return repository.findAll();
    }

    public Optional<Book> getBookById(int id) {
        return repository.findById(id);
    }

    public Book addBook(Book book) {
        return repository.save(book);
    }

    public Optional<Book> updateBook(int id, Book updatedBook) {

        if (!repository.existsById(id)) {
            return Optional.empty();
        }

        updatedBook.setBookId(id);

        return Optional.of(repository.save(updatedBook));
    }

    public boolean deleteBook(int id) {

        if (!repository.existsById(id)) {
            return false;
        }

        repository.deleteById(id);

        return true;
    }

    public List<Book> searchByCategory(String category) {
        return repository.findByCategoryIgnoreCase(category);
    }

    public List<Book> filterByYear(int year) {
        return repository.findByPublicationYearGreaterThanEqual(year);
    }
}
